public class Card {

    private int rank;

    public Card(int r) {
        rank = r;
    }

    public int getRank() {
        return rank;
    }
}